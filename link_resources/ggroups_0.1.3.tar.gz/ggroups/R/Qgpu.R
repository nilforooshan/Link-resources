#' @name Qgpu
#'
#' @title Vector \strong{Qg} + \strong{u}
#'
#' @description Adds genetic group contributions to genetic merit of animals in a pedigree.
#'
#' @param
#' Q : The output matrix from \code{qmat}; for more details: \code{?qmat}
#' sol : A \code{data.frame} with numeric columns corresponding to ID, EBV ([\strong{ĝ}, \strong{û}]).
#'
#' @return uhatplus : Vector of \strong{Qĝ} + \strong{û}
#'
#' @examples
#' ped = data.frame(ID=c(3,4,6,5), SIRE=c(1,3,4,1), DAM=c(2,2,5,2))
#' Q = qmat(gghead(ped))
#' ghat = c(0.1, -0.1)
#' uhat = seq(-0.15, 0.15, 0.1)
#' sol = data.frame(ID=1:6, EBV=c(ghat, uhat))
#' Qgpu(Q, sol)
#'
#' @export
Qgpu = function(Q, sol) {
   if(identical(as.integer(c(colnames(Q), rownames(Q))), sol$ID))
   {
      Ngg = ncol(Q)
      ghat = sol[1:Ngg,]$EBV
      uhat = sol[(Ngg + 1):nrow(sol),]$EBV
      uhatplus = (Q %*% ghat) + uhat
      return(uhatplus)
   } else {
      print("ERROR: identical(c(colnames(Q), rownames(Q)), sol$ID) = FALSE")
   }
}
