#' @title Vector \strong{Qg} + \strong{u}
#'
#' @description Adds genetic group contributions to the genetic merit of animals.
#'
#' @param Q : The output matrix from \code{qmat} (for more details: \code{?qmat})
#'
#' @param sol : \code{data.frame} with 2 numeric columns corresponding to ID, EBV ([\strong{g}, \strong{u}]), where \strong{g} and \strong{u} are the genetic group and genetic merit solutions, respectively. The order of solutions must be the order of columns and the order of rows in matrix \strong{Q}.
#'
#' @return Vector of \strong{Qg} + \strong{u}
#'
#' @examples
#' ped = data.frame(ID=c(3,4,6,5), SIRE=c(1,3,4,1), DAM=c(2,2,5,2))
#' Q = qmat(gghead(ped))
#' ghat = c(0.1, -0.2)
#' uhat = seq(-1.5, 1.5, 1)
#' sol = data.frame(ID=1:6, EBV=c(ghat, uhat))
#' Qgpu(Q, sol)
#'
#' @export
Qgpu = function(Q, sol) {
   if(identical(as.integer(c(colnames(Q), rownames(Q))), sol$ID))
   {
      colnames(sol) = c("ID","EBV")
      Ngg = ncol(Q)
      ghat = sol[1:Ngg,]$EBV
      uhat = sol[(Ngg + 1):nrow(sol),]$EBV
      uhatplus = (Q %*% ghat) + uhat
      return(uhatplus)
   } else {
      print("ERROR: identical(c(colnames(Q), rownames(Q)), sol$ID) = FALSE")
   }
}
